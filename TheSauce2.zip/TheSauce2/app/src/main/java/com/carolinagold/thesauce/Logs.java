package com.carolinagold.thesauce;

/**
 * Created by woodyjean-louis on 12/4/16.
 */

public class Logs {
    public static final String ERROR_IN_TRY = "Error in try";
    public static final String POINT_OF_INTEREST = "Point of interest";
}
